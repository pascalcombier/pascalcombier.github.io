local http = require("http")
local json = require("serde").json
local airtable = {}

local dangerousPatterns = {
	"IF%s*%(",
	"SWITCH%s*%(",
	"ERROR%s*%(",
	"RECORD_ID%s*%(",
	"CREATED_TIME%s*%(",
	"LAST_MODIFIED_TIME%s*%(",
	"REGEX_MATCH%s*%(",
	"REGEX_REPLACE%s*%(",
	"REGEX_EXTRACT%s*%(",
}

function airtable.sanitizeFormulaValue(value)
	if type(value) ~= "string" then
		return tostring(value)
	end
	local sanitized = value:gsub('"', '\\"')
	sanitized = sanitized:gsub("'", "\\'")
	sanitized = sanitized:gsub("%(", "")
	sanitized = sanitized:gsub("%)", "")
	return sanitized
end

function airtable.validateFormula(formula)
	if type(formula) ~= "string" then
		return false, "formula must be a string"
	end
	local upper = formula:upper()
	for _, pattern in ipairs(dangerousPatterns) do
		if upper:match(pattern:upper()) then
			return false, "potentially dangerous formula pattern detected: " .. pattern
		end
	end
	return true
end

local function get_api_key()
	local key = os.getenv("AIRTABLE_API_KEY")
	if not key or key == "" then
		return nil, "AIRTABLE_API_KEY not set in environment or .env file"
	end
	return key
end


local function build_headers()
	local api_key, err = get_api_key()
	if not api_key then
		pprint({ error = "missing_airtable_api_key", message = err })
		return nil, err
	end

	return {
		["Authorization"] = "Bearer " .. api_key,
		["Content-Type"] = "application/json"
	}
end

local function validateInput(input)
	if type(input) ~= "string" or input == "" then
		return nil
	else 
		return true
	end
end

local function validateBaseId(base_id)
	if type(base_id) ~= "string" or base_id == "" then
		return nil, "base_id must be a non-empty string"
	end
	if not base_id:match("^app[%w]+$") then
		return nil, "Invalid base_id format (must start with 'app' followed by alphanumeric characters)"
	end
	if base_id:match("%.%.") or base_id:match("[/\\]") then
		return nil, "Invalid base_id (contains forbidden characters)"
	end
	return true
end

local function validateRecordId(record_id)
	if type(record_id) ~= "string" or record_id == "" then
		return nil, "record_id must be a non-empty string"
	end
	if not record_id:match("^rec[%w]+$") then
		return nil, "Invalid record_id format (must start with 'rec' followed by alphanumeric characters)"
	end
	return true
end

local function validateTableId(table_id)
	if type(table_id) ~= "string" or table_id == "" then
		return nil, "table_id must be a non-empty string"
	end
	if not table_id:match("^tbl[%w]+$") then
		return nil, "Invalid table_id format (must start with 'tbl' followed by alphanumeric characters)"
	end
	return true
end

local function validateFieldId(field_id)
	if type(field_id) ~= "string" or field_id == "" then
		return nil, "field_id must be a non-empty string"
	end
	if not field_id:match("^fld[%w]+$") then
		return nil, "Invalid field_id format (must start with 'fld' followed by alphanumeric characters)"
	end
	return true
end

local function validateCommentId(comment_id)
	if type(comment_id) ~= "string" or comment_id == "" then
		return nil, "comment_id must be a non-empty string"
	end
	if not comment_id:match("^com[%w]+$") then
		return nil, "Invalid comment_id format (must start with 'com' followed by alphanumeric characters)"
	end
	return true
end

local function validateWorkspaceId(workspace_id)
	if type(workspace_id) ~= "string" or workspace_id == "" then
		return nil, "workspace_id must be a non-empty string"
	end
	if not workspace_id:match("^wsp[%w]+$") then
		return nil, "Invalid workspace_id format (must start with 'wsp' followed by alphanumeric characters)"
	end
	return true
end

local function validateTableName(table_name)
	if type(table_name) ~= "string" or table_name == "" then
		return nil, "table_name must be a non-empty string"
	end
	if table_name:match("%.%.") or table_name:match("[/\\]") then
		return nil, "Invalid table_name (contains forbidden characters)"
	end
	if #table_name > 255 then
		return nil, "table_name exceeds maximum length"
	end
	return true
end

local function url_encode(str)
	return str:gsub("([^%w%-_%.~])", function(c)
		return string.format("%%%02X", string.byte(c))
	end)
end

function airtable.list(base_id, table_name, view, params)
	local valid, err = validateTableName(table_name)
	if not valid then
		return nil, err
	end

	local validBase, baseErr = validateBaseId(base_id)
	if not validBase then
		return nil, baseErr
	end

	local headers, herr = build_headers()
	if not headers then
		return nil, herr
	end

	local url = "https://api.airtable.com/v0/" .. base_id .. "/" .. url_encode(table_name) .. "/listRecords"
	local body = {}
	if params and type(params) == "table" then
		for k, v in pairs(params) do
			body[k] = v
		end
		if body.filterByFormula then
			local valid, err = airtable.validateFormula(body.filterByFormula)
			if not valid then
				return nil, "Invalid filter by formula"
			end
		end
	end
	if view and type(view) == "string" and view ~= "" then
		body["view"] = view
	end

	local ok, res_or_err = pcall(function()
		return http.request {
			url = url,
			method = "POST",
			headers = headers,
			body = json.encode(body)
		}:execute()
	end)

	if not ok then
		return nil, res_or_err
	end

	local res = res_or_err

	if not res then
		return nil, "No response from airtable"
	end

	local status = res:status_code()
	local body_text = nil
	local ok2, dec = pcall(function()
		body_text = res:body() and res:body():text() or nil
		return body_text and json.decode(body_text) or nil
	end)

	if status >= 400 then
		return ok2 and dec or nil, status
	end

	return ok2 and dec or nil
end

function airtable.get(base_id, table_name, record_id)
	local valid, err = validateTableName(table_name)
	if not valid then
		return nil, err
	end

	local validRec, recErr = validateRecordId(record_id)
	if not validRec then
		return nil, recErr
	end

	local validBase, baseErr = validateBaseId(base_id)
	if not validBase then
		return nil, baseErr
	end

	local headers, herr = build_headers()
	if not headers then
		return nil, herr
	end

	local url = "https://api.airtable.com/v0/" .. base_id .. "/" .. url_encode(table_name) .. "/" .. url_encode(record_id)

	local ok, res_or_err = pcall(function()
		return http.request {
			url = url,
			method = "GET",
			headers = headers,
		}:execute()
	end)

	if not ok then
		return nil, res_or_err
	end

	local res = res_or_err

	if not res then
		return nil, "No response from airtable"
	end

	local status = res:status_code()
	local body_text = nil
	local ok2, dec = pcall(function()
		body_text = res:body() and res:body():text() or nil
		return body_text and json.decode(body_text) or nil
	end)

	if status >= 400 then
		return ok2 and dec or nil, status
	end

	return ok2 and dec or nil
end

function airtable.getByField(base_id, table_name, field, value)
	local valid, err = validateTableName(table_name)
	if not valid then
		return nil, err
	end

	if not validateInput(field) then
		return nil, "Invalid field"
	end

	if not validateInput(value) then
		return nil, "Invalid value"
	end

	local validBase, baseErr = validateBaseId(base_id)
	if not validBase then
		return nil, baseErr
	end

	local safeField = airtable.sanitizeFormulaValue(field)
	local safeValue = airtable.sanitizeFormulaValue(value)
	local formula = "{" .. safeField .. "} = \"" .. safeValue .. "\""

	local records, err = airtable.list(base_id, table_name, nil, {filterByFormula = formula})

	if records then
		return records.records[1]
	else 
		return nil, err
	end


end

function airtable.update(base_id, table_name, record_id, fields)
	local valid, err = validateTableName(table_name)
	if not valid then
		return nil, err
	end

	local validRec, recErr = validateRecordId(record_id)
	if not validRec then
		return nil, recErr
	end

	local validBase, baseErr = validateBaseId(base_id)
	if not validBase then
		return nil, baseErr
	end

	local headers, herr = build_headers()
	if not headers then
		return nil, herr
	end

	local body = {fields = fields}

	local url = "https://api.airtable.com/v0/" .. base_id .. "/" .. url_encode(table_name) .. "/" .. url_encode(record_id)

	local ok, res_or_err = pcall(function()
		return http.request {
			url = url,
			method = "PATCH",
			headers = headers,
			body = json.encode(body)
		}:execute()
	end)

	if not ok then
		return nil, res_or_err
	end

	local res = res_or_err

	if not res then
		return nil, "No response from airtable"
	end

	local status = res:status_code()
	local body_text = nil
	local ok2, dec = pcall(function()
		body_text = res:body() and res:body():text() or nil
		return body_text and json.decode(body_text) or nil
	end)

	if status >= 400 then
		return ok2 and dec or nil, status
	end

	return ok2 and dec or nil
end

function airtable.updateByField(base_id, table_name, field, value, updatedFields)
	local valid, err = validateTableName(table_name)
	if not valid then
		return nil, err
	end

	if not validateInput(field) then
		return nil, "Invalid field"
	end

	if not validateInput(value) then
		return nil, "Invalid value"
	end

	local validBase, baseErr = validateBaseId(base_id)
	if not validBase then
		return nil, baseErr
	end

	if not updatedFields then
		return nil, "Missing fields to update"
	end

	local safeField = airtable.sanitizeFormulaValue(field)
	local safeValue = airtable.sanitizeFormulaValue(value)
	local formula = "{" .. safeField .. "} = \"" .. safeValue .. "\""

	local records, err = airtable.list(base_id, table_name, nil, {filterByFormula = formula})
	local recId 
	if records and records.records and records.records[1] then
		recId = records.records[1].id
	else 
		return nil, err or "No record found"
	end

	local record, err2 = airtable.update(base_id, table_name, recId, updatedFields) 

	if err2 then
		return nil, err2
	else 
		return record 
	end
	
end

function airtable.create(base_id, table_name, fields)
	local valid, err = validateTableName(table_name)
	if not valid then
		return nil, err
	end

	local validBase, baseErr = validateBaseId(base_id)
	if not validBase then
		return nil, baseErr
	end

	local headers, herr = build_headers()
	if not headers then
		return nil, herr
	end

	local body = {}

	if fields then
		body = {fields = fields}
	end

	local url = "https://api.airtable.com/v0/" .. base_id .. "/" .. url_encode(table_name)

	local ok, res_or_err = pcall(function()
		return http.request {
			url = url,
			method = "POST",
			headers = headers,
			body = json.encode(body)
		}:execute()
	end)

	if not ok then
		return nil, res_or_err
	end

	local res = res_or_err

	if not res then
		return nil, "No response from airtable"
	end

	local status = res:status_code()
	local body_text = nil
	local ok2, dec = pcall(function()
		body_text = res:body() and res:body():text() or nil
		return body_text and json.decode(body_text) or nil
	end)

	if status >= 400 then
		return ok2 and dec or nil, status
	end

	return ok2 and dec or nil
end

function airtable.delete(base_id, table_name, record_id)
	local valid, err = validateTableName(table_name)
	if not valid then
		return nil, err
	end

	local validRec, recErr = validateRecordId(record_id)
	if not validRec then
		return nil, recErr
	end

	local validBase, baseErr = validateBaseId(base_id)
	if not validBase then
		return nil, baseErr
	end

	local headers, herr = build_headers()
	if not headers then
		return nil, herr
	end

	local url = "https://api.airtable.com/v0/" .. base_id .. "/" .. url_encode(table_name) .. "/" .. url_encode(record_id)

	local ok, res_or_err = pcall(function()
		return http.request {
			url = url,
			method = "DELETE",
			headers = headers
		}:execute()
	end)

	if not ok then
		return nil, res_or_err
	end

	local res = res_or_err

	if not res then
		return nil, "No response from airtable"
	end

	local status = res:status_code()
	local body_text = nil
	local ok2, dec = pcall(function()
		body_text = res:body() and res:body():text() or nil
		return body_text and json.decode(body_text) or nil
	end)

	if status >= 400 then
		return ok2 and dec or nil, status
	end

	return ok2 and dec or nil
end

function airtable.createBulk(base_id, table_name, recordsArray)
	local valid, err = validateTableName(table_name)
	if not valid then
		return nil, err
	end

	local validBase, baseErr = validateBaseId(base_id)
	if not validBase then
		return nil, baseErr
	end

	if not recordsArray or type(recordsArray) ~= "table" or #recordsArray == 0 then
		return nil, "recordsArray must be a non-empty array"
	end

	if #recordsArray > 10 then
		return nil, "Airtable API allows a maximum of 10 records per request"
	end

	local headers, herr = build_headers()
	if not headers then
		return nil, herr
	end

	local records = {}
	for _, fields in ipairs(recordsArray) do
		table.insert(records, {fields = fields})
	end

	local body = {records = records}
	local url = "https://api.airtable.com/v0/" .. base_id .. "/" .. url_encode(table_name)

	local ok, res_or_err = pcall(function()
		return http.request {
			url = url,
			method = "POST",
			headers = headers,
			body = json.encode(body)
		}:execute()
	end)

	if not ok then
		return nil, res_or_err
	end

	local res = res_or_err

	if not res then
		return nil, "No response from airtable"
	end

	local status = res:status_code()
	local body_text = nil
	local ok2, dec = pcall(function()
		body_text = res:body() and res:body():text() or nil
		return body_text and json.decode(body_text) or nil
	end)

	if status >= 400 then
		return ok2 and dec or nil, status
	end

	return ok2 and dec or nil
end

function airtable.updateBulk(base_id, table_name, recordsArray)
	local valid, err = validateTableName(table_name)
	if not valid then
		return nil, err
	end

	local validBase, baseErr = validateBaseId(base_id)
	if not validBase then
		return nil, baseErr
	end

	if not recordsArray or type(recordsArray) ~= "table" or #recordsArray == 0 then
		return nil, "recordsArray must be a non-empty array"
	end

	if #recordsArray > 10 then
		return nil, "Airtable API allows a maximum of 10 records per request"
	end

	local headers, herr = build_headers()
	if not headers then
		return nil, herr
	end

	local records = {}
	for _, record in ipairs(recordsArray) do
		if not record.id or not record.fields then
			return nil, "Each record must have 'id' and 'fields' properties"
		end
		local validRec, recErr = validateRecordId(record.id)
		if not validRec then
			return nil, recErr
		end
		table.insert(records, {id = record.id, fields = record.fields})
	end

	local body = {records = records}
	local url = "https://api.airtable.com/v0/" .. base_id .. "/" .. url_encode(table_name)

	local ok, res_or_err = pcall(function()
		return http.request {
			url = url,
			method = "PATCH",
			headers = headers,
			body = json.encode(body)
		}:execute()
	end)

	if not ok then
		return nil, res_or_err
	end

	local res = res_or_err

	if not res then
		return nil, "No response from airtable"
	end

	local status = res:status_code()
	local body_text = nil
	local ok2, dec = pcall(function()
		body_text = res:body() and res:body():text() or nil
		return body_text and json.decode(body_text) or nil
	end)

	if status >= 400 then
		return ok2 and dec or nil, status
	end

	return ok2 and dec or nil
end

function airtable.deleteBulk(base_id, table_name, recordIds)
	local valid, err = validateTableName(table_name)
	if not valid then
		return nil, err
	end

	local validBase, baseErr = validateBaseId(base_id)
	if not validBase then
		return nil, baseErr
	end

	if not recordIds or type(recordIds) ~= "table" or #recordIds == 0 then
		return nil, "recordIds must be a non-empty array"
	end

	if #recordIds > 10 then
		return nil, "Airtable API allows a maximum of 10 records per request"
	end

	local headers, herr = build_headers()
	if not headers then
		return nil, herr
	end

	local queryParams = {}
	for _, id in ipairs(recordIds) do
		local validRec, recErr = validateRecordId(id)
		if not validRec then
			return nil, recErr
		end
		table.insert(queryParams, "records[]=" .. url_encode(id))
	end

	local url = "https://api.airtable.com/v0/" .. base_id .. "/" .. url_encode(table_name) .. "?" .. table.concat(queryParams, "&")

	local ok, res_or_err = pcall(function()
		return http.request {
			url = url,
			method = "DELETE",
			headers = headers
		}:execute()
	end)

	if not ok then
		return nil, res_or_err
	end

	local res = res_or_err

	if not res then
		return nil, "No response from airtable"
	end

	local status = res:status_code()
	local body_text = nil
	local ok2, dec = pcall(function()
		body_text = res:body() and res:body():text() or nil
		return body_text and json.decode(body_text) or nil
	end)

	if status >= 400 then
		return ok2 and dec or nil, status
	end

	return ok2 and dec or nil
end

function airtable.updateField(base_id, table_id, field_id, options)
	local validBase, baseErr = validateBaseId(base_id)
	if not validBase then
		return nil, baseErr
	end

	local validTbl, tblErr = validateTableId(table_id)
	if not validTbl then
		return nil, tblErr
	end

	local validFld, fldErr = validateFieldId(field_id)
	if not validFld then
		return nil, fldErr
	end

	if not options or type(options) ~= "table" then
		return nil, "Options must be a table"
	end

	if not options.name and not options.description then
		return nil, "At least one of name or description must be specified"
	end

	if options.description and type(options.description) == "string" and #options.description > 20000 then
		return nil, "Description must be no longer than 20,000 characters"
	end

	local headers, herr = build_headers()
	if not headers then
		return nil, herr
	end

	local body = {}
	if options.name then
		body.name = options.name
	end
	if options.description then
		body.description = options.description
	end

	local url = "https://api.airtable.com/v0/meta/bases/" .. base_id .. "/tables/" .. url_encode(table_id) .. "/fields/" .. url_encode(field_id)

	local ok, res_or_err = pcall(function()
		return http.request {
			url = url,
			method = "PATCH",
			headers = headers,
			body = json.encode(body)
		}:execute()
	end)

	if not ok then
		return nil, res_or_err
	end

	local res = res_or_err

	if not res then
		return nil, "No response from airtable"
	end

	local status = res:status_code()
	local body_text = nil
	local ok2, dec = pcall(function()
		body_text = res:body() and res:body():text() or nil
		return body_text and json.decode(body_text) or nil
	end)

	if status >= 400 then
		return ok2 and dec or nil, status
	end

	return ok2 and dec or nil
end

function airtable.createField(base_id, table_id, fieldtype, options)
	local validBase, baseErr = validateBaseId(base_id)
	if not validBase then
		return nil, baseErr
	end

	local validTbl, tblErr = validateTableId(table_id)
	if not validTbl then
		return nil, tblErr
	end

	if not validateInput(fieldtype) then
		return nil, "Invalid type"
	end

	if not options or type(options) ~= "table" then
		return nil, "Options must be a table"
	end

	if not options.name and not options.description then
		return nil, "At least one of name or description must be specified"
	end

	if options.description and type(options.description) == "string" and #options.description > 20000 then
		return nil, "Description must be no longer than 20,000 characters"
	end

	local headers, herr = build_headers()
	if not headers then
		return nil, herr
	end

	local body = {}
	if options.name then
		body.name = options.name
	end
	if options.description then
		body.description = options.description
	end

	body.type = fieldtype

	local url = "https://api.airtable.com/v0/meta/bases/" .. base_id .. "/tables/" .. url_encode(table_id) .. "/fields"

	local ok, res_or_err = pcall(function()
		return http.request {
			url = url,
			method = "POST",
			headers = headers,
			body = json.encode(body)
		}:execute()
	end)

	if not ok then
		return nil, res_or_err
	end

	local res = res_or_err

	if not res then
		return nil, "No response from airtable"
	end

	local status = res:status_code()
	local body_text = nil
	local ok2, dec = pcall(function()
		body_text = res:body() and res:body():text() or nil
		return body_text and json.decode(body_text) or nil
	end)

	if status >= 400 then
		return ok2 and dec or nil, status
	end

	return ok2 and dec or nil
end

function airtable.listComments(base_id, table_name, record_id)
	local valid, err = validateTableName(table_name)
	if not valid then
		return nil, err
	end

	local validRec, recErr = validateRecordId(record_id)
	if not validRec then
		return nil, recErr
	end

	local validBase, baseErr = validateBaseId(base_id)
	if not validBase then
		return nil, baseErr
	end

	local headers, herr = build_headers()
	if not headers then
		return nil, herr
	end

	local url = "https://api.airtable.com/v0/" .. base_id .. "/" .. url_encode(table_name) .. "/" .. url_encode(record_id) .. "/comments"

	local ok, res_or_err = pcall(function()
		return http.request {
			url = url,
			method = "GET",
			headers = headers,
		}:execute()
	end)

	if not ok then
		return nil, res_or_err
	end

	local res = res_or_err

	if not res then
		return nil, "No response from airtable"
	end

	local status = res:status_code()
	local body_text = nil
	local ok2, dec = pcall(function()
		body_text = res:body() and res:body():text() or nil
		return body_text and json.decode(body_text) or nil
	end)

	if status >= 400 then
		return ok2 and dec or nil, status
	end

	return ok2 and dec or nil
end

function airtable.updateComment(base_id, table_name, record_id, comment_id, content)
	local valid, err = validateTableName(table_name)
	if not valid then
		return nil, err
	end

	local validRec, recErr = validateRecordId(record_id)
	if not validRec then
		return nil, recErr
	end

	local validBase, baseErr = validateBaseId(base_id)
	if not validBase then
		return nil, baseErr
	end

	local validCom, comErr = validateCommentId(comment_id)
	if not validCom then
		return nil, comErr
	end

	if not validateInput(content) then
		return nil, "Invalid content (must be a string)"
	end

	local headers, herr = build_headers()
	if not headers then
		return nil, herr
	end

	local body = {text = content}

	local url = "https://api.airtable.com/v0/" .. base_id .. "/" .. url_encode(table_name) .. "/" .. url_encode(record_id) .. "/comments" .. url_encode(comment_id)

	local ok, res_or_err = pcall(function()
		return http.request {
			url = url,
			method = "PATCH",
			headers = headers,
			body = json.encode(body)
		}:execute()
	end)

	if not ok then
		return nil, res_or_err
	end

	local res = res_or_err

	if not res then
		return nil, "No response from airtable"
	end

	local status = res:status_code()
	local body_text = nil
	local ok2, dec = pcall(function()
		body_text = res:body() and res:body():text() or nil
		return body_text and json.decode(body_text) or nil
	end)

	if status >= 400 then
		return ok2 and dec or nil, status
	end

	return ok2 and dec or nil
end

function airtable.createComment(base_id, table_name, record_id, text, parentCommentId)
	local valid, err = validateTableName(table_name)
	if not valid then
		return nil, err
	end

	local validRec, recErr = validateRecordId(record_id)
	if not validRec then
		return nil, recErr
	end

	local validBase, baseErr = validateBaseId(base_id)
	if not validBase then
		return nil, baseErr
	end

	if not validateInput(text) then
		return nil, "Invalid text (must be a string)"
	end

	local headers, herr = build_headers()
	if not headers then
		return nil, herr
	end

	local body = {text = text}
	if parentCommentId then
		local validCom, comErr = validateCommentId(parentCommentId)
		if not validCom then
			return nil, comErr
		end
		body.parentCommentId = parentCommentId
	end

	local url = "https://api.airtable.com/v0/" .. base_id .. "/" .. url_encode(table_name) .. "/" .. url_encode(record_id) .. "/comments"

	local ok, res_or_err = pcall(function()
		return http.request {
			url = url,
			method = "POST",
			headers = headers,
			body = json.encode(body)
		}:execute()
	end)

	if not ok then
		return nil, res_or_err
	end

	local res = res_or_err

	if not res then
		return nil, "No response from airtable"
	end

	local status = res:status_code()
	local body_text = nil
	local ok2, dec = pcall(function()
		body_text = res:body() and res:body():text() or nil
		return body_text and json.decode(body_text) or nil
	end)

	if status >= 400 then
		return ok2 and dec or nil, status
	end

	return ok2 and dec or nil
end

function airtable.createTable(base_id, name, fields, description)
	local validBase, baseErr = validateBaseId(base_id)
	if not validBase then
		return nil, baseErr
	end

	local valid, err = validateTableName(name)
	if not valid then
		return nil, err
	end

	if not fields or type(fields) ~= "table" or #fields == 0 then
		return nil, "fields must be a non-empty array"
	end

	if description and type(description) == "string" and #description > 20000 then
		return nil, "Description must be no longer than 20,000 characters"
	end

	local headers, herr = build_headers()
	if not headers then
		return nil, herr
	end

	local body = {
		name = name,
		fields = fields
	}

	if description and type(description) == "string" and description ~= "" then
		body.description = description
	end

	local url = "https://api.airtable.com/v0/meta/bases/" .. base_id .. "/tables"

	local ok, res_or_err = pcall(function()
		return http.request {
			url = url,
			method = "POST",
			headers = headers,
			body = json.encode(body)
		}:execute()
	end)

	if not ok then
		return nil, res_or_err
	end

	local res = res_or_err

	if not res then
		return nil, "No response from airtable"
	end

	local status = res:status_code()
	local body_text = nil
	local ok2, dec = pcall(function()
		body_text = res:body() and res:body():text() or nil
		return body_text and json.decode(body_text) or nil
	end)

	if status >= 400 then
		return ok2 and dec or nil, status
	end

	return ok2 and dec or nil
end

function airtable.updateTable(base_id, table_id, options)
	local validBase, baseErr = validateBaseId(base_id)
	if not validBase then
		return nil, baseErr
	end

	local validTbl, tblErr = validateTableId(table_id)
	if not validTbl then
		return nil, tblErr
	end

	if not options or type(options) ~= "table" then
		return nil, "Options must be a table"
	end

	if not options.name and not options.description and not options.dateDependencySettings then
		return nil, "At least one of name, description, or dateDependencySettings must be specified"
	end

	if options.description and type(options.description) == "string" and #options.description > 20000 then
		return nil, "Description must be no longer than 20,000 characters"
	end

	local headers, herr = build_headers()
	if not headers then
		return nil, herr
	end

	local body = {}
	if options.name then
		body.name = options.name
	end
	if options.description then
		body.description = options.description
	end
	if options.dateDependencySettings then
		body.dateDependencySettings = options.dateDependencySettings
	end

	local url = "https://api.airtable.com/v0/meta/bases/" .. base_id .. "/tables/" .. url_encode(table_id)

	local ok, res_or_err = pcall(function()
		return http.request {
			url = url,
			method = "PATCH",
			headers = headers,
			body = json.encode(body)
		}:execute()
	end)

	if not ok then
		return nil, res_or_err
	end

	local res = res_or_err

	if not res then
		return nil, "No response from airtable"
	end

	local status = res:status_code()
	local body_text = nil
	local ok2, dec = pcall(function()
		body_text = res:body() and res:body():text() or nil
		return body_text and json.decode(body_text) or nil
	end)

	if status >= 400 then
		return ok2 and dec or nil, status
	end

	return ok2 and dec or nil
end

function airtable.listBases(offset)
	local headers, herr = build_headers()
	if not headers then
		return nil, herr
	end

	local url = "https://api.airtable.com/v0/meta/bases"
	if offset and type(offset) == "string" and offset ~= "" then
		url = url .. "?offset=" .. url_encode(offset)
	end

	local ok, res_or_err = pcall(function()
		return http.request {
			url = url,
			method = "GET",
			headers = headers,
		}:execute()
	end)

	if not ok then
		return nil, res_or_err
	end

	local res = res_or_err

	if not res then
		return nil, "No response from airtable"
	end

	local status = res:status_code()
	local body_text = nil
	local ok2, dec = pcall(function()
		body_text = res:body() and res:body():text() or nil
		return body_text and json.decode(body_text) or nil
	end)

	if status >= 400 then
		return ok2 and dec or nil, status
	end

	return ok2 and dec or nil
end

function airtable.getBaseSchema(base_id, include)
	local validBase, baseErr = validateBaseId(base_id)
	if not validBase then
		return nil, baseErr
	end

	local headers, herr = build_headers()
	if not headers then
		return nil, herr
	end

	local url = "https://api.airtable.com/v0/meta/bases/" .. base_id .. "/tables"
	if include and type(include) == "table" and #include > 0 then
		local includeParams = {}
		for _, v in ipairs(include) do
			table.insert(includeParams, "include=" .. url_encode(v))
		end
		url = url .. "?" .. table.concat(includeParams, "&")
	end

	local ok, res_or_err = pcall(function()
		return http.request {
			url = url,
			method = "GET",
			headers = headers,
		}:execute()
	end)

	if not ok then
		return nil, res_or_err
	end

	local res = res_or_err

	if not res then
		return nil, "No response from airtable"
	end

	local status = res:status_code()
	local body_text = nil
	local ok2, dec = pcall(function()
		body_text = res:body() and res:body():text() or nil
		return body_text and json.decode(body_text) or nil
	end)

	if status >= 400 then
		return ok2 and dec or nil, status
	end

	return ok2 and dec or nil
end

function airtable.createBase(workspace_id, name, tables)
	local validWsp, wspErr = validateWorkspaceId(workspace_id)
	if not validWsp then
		return nil, wspErr
	end

	if not validateInput(name) then
		return nil, "Invalid base name"
	end
	if name:match("%.%.") or name:match("[/\\]") then
		return nil, "Invalid base name (contains forbidden characters)"
	end

	if not tables or type(tables) ~= "table" or #tables == 0 then
		return nil, "tables must be a non-empty array"
	end

	local headers, herr = build_headers()
	if not headers then
		return nil, herr
	end

	local body = {
		name = name,
		workspaceId = workspace_id,
		tables = tables
	}

	local url = "https://api.airtable.com/v0/meta/bases"

	local ok, res_or_err = pcall(function()
		return http.request {
			url = url,
			method = "POST",
			headers = headers,
			body = json.encode(body)
		}:execute()
	end)

	if not ok then
		return nil, res_or_err
	end

	local res = res_or_err

	if not res then
		return nil, "No response from airtable"
	end

	local status = res:status_code()
	local body_text = nil
	local ok2, dec = pcall(function()
		body_text = res:body() and res:body():text() or nil
		return body_text and json.decode(body_text) or nil
	end)

	if status >= 400 then
		return ok2 and dec or nil, status
	end

	return ok2 and dec or nil
end

function airtable.deleteComment(base_id, table_name, record_id, comment_id)
	local valid, err = validateTableName(table_name)
	if not valid then
		return nil, err
	end

	local validRec, recErr = validateRecordId(record_id)
	if not validRec then
		return nil, recErr
	end

	local validBase, baseErr = validateBaseId(base_id)
	if not validBase then
		return nil, baseErr
	end

	local validCom, comErr = validateCommentId(comment_id)
	if not validCom then
		return nil, comErr
	end

	local headers, herr = build_headers()
	if not headers then
		return nil, herr
	end

	local url = "https://api.airtable.com/v0/" .. base_id .. "/" .. url_encode(table_name) .. "/" .. url_encode(record_id) .. "/comments/" .. url_encode(comment_id)

	local ok, res_or_err = pcall(function()
		return http.request {
			url = url,
			method = "DELETE",
			headers = headers
		}:execute()
	end)

	if not ok then
		return nil, res_or_err
	end

	local res = res_or_err

	if not res then
		return nil, "No response from airtable"
	end

	local status = res:status_code()
	local body_text = nil
	local ok2, dec = pcall(function()
		body_text = res:body() and res:body():text() or nil
		return body_text and json.decode(body_text) or nil
	end)

	if status >= 400 then
		return ok2 and dec or nil, status
	end

	return ok2 and dec or nil
end

return airtable

