# coro-fs

Luarocks port of lit's [coro-fs](https://github.com/luvit/lit/blob/master/deps/coro-fs.lua)

## License

coro-fs is originally written by Tim Caswell under MIT license

[Here](https://github.com/code-nuage/coro-fs/blob/main/LICENSE) it is.
