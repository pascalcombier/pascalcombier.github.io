{
  {
    filename = "30log-0.8.0.zip",
    dependencies = {
      "lua >= 5.1",
    },
  },
  {
    filename = "ac-clientoutput-1.1.1.zip",
    dependencies = {
      "lua >= 5.1",
    },
  },
  {
    filename = "abacatepaysdk-1.0.zip",
    dependencies = {
      "socket >= 5.1",
      "ltn12 >= 5.1",
    },
  },
  {
    filename = "abstk-release-1.zip",
    dependencies = {
      "lgi >= 0.9.1",
      "lcurses >= 9.0",
    },
  },
  {
    filename = "access-token-introspection-1.0.0.zip",
  },
  {
    filename = "uint-0.186.zip",
    dependencies = {
      "lua >= 5.1",
    },
  },
}
