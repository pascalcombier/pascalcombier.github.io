-- 19-06-2025 @author Swarg
--
-- simple http client, lightweigh version of lhttp
--

local log = require 'alogger'

local cjson = require 'cjson'
local http = require 'socket.http'
local socket_url = require 'socket.url'
local ltn12 = require 'ltn12'

local M = {}


M.CT_APP_JSON = 'application/json'

local log_debug = log.debug

--
--
--
---@param method string
---@param url string
---@param payload string|table?
---@param headers table?
---@return string|table response
---@return number? code
---@return table resp_headers
function M.send(method, url, headers, payload)
  local t_response = {}

  local source = nil
  if type(payload) == 'table' and payload ~= '' then
    payload = cjson.encode(payload)
  end
  if type(payload) == 'string' and payload ~= '' then
    source = ltn12.source.string(payload);
  end

  headers = headers or {}

  local r, code, resp_headers, status = http.request({
    method = assert(method, 'method'),
    url = assert(url, 'url'),
    headers = headers or {},
    sink = ltn12.sink.table(t_response),
    source = source, -- to send post data (nullable) (post payload)
  })

  if log.is_debug() then
    log_debug('send %s url:%s ret:%s code:%s status:%s resp-ct:%s req-payload:%s',
      method, url,
      r, code, status, M.get_content_type(resp_headers),
      payload)

    if code ~= 200 then
      local i = require "inspect"
      log_debug("%s %s", i(resp_headers), i(t_response))
    end
  end

  local response = table.concat(t_response)

  return response, code, resp_headers
end

---@param url string
---@param headers table?
---@return string|table response
---@return number? code
---@return table resp_headers
function M.send_get(url, headers)
  return M.send('GET', url, headers, nil)
end

---@param headers table?
---@param auth_token string?
---@param user_agent string?
---@return table
function M.add_auth_header(headers, auth_token, user_agent)
  headers = headers or {}
  if auth_token then
    headers['authorization'] = 'Bearer ' .. tostring(auth_token)
  end
  if user_agent then
    headers['user-agent'] = user_agent
  end
  return headers
end

---@param h table?
function M.get_content_type(h)
  if type(h) == 'table' then
    return h['content-type'] or h['Content-Type']
  end
  return nil
end

---@param method string
---@param url string
---@param payload table|string?
---@param headers table?
function M.sendJsonO(method, url, payload, headers)
  assert(type(url) == 'string', 'url')
  headers = headers or {}
  headers['content-type'] = headers['content-type'] or M.CT_APP_JSON
  headers.accept = headers.accept or M.CT_APP_JSON

  local resp, code, resp_headers = M.send(method, url, headers, payload)
  if M.get_content_type(resp_headers) == M.CT_APP_JSON then
    local ok, ret = pcall(function()
      return cjson.decode(resp)
    end)
    if not ok or type(ret) ~= 'table' then
      log.error('on decode json from %s: %s', url, ret)
    else
      resp = ret
    end
  end

  return resp, code, resp_headers
end

function M.getJsonO(url, headers)
  return M.sendJsonO('GET', url, nil, headers)
end

function M.postJsonO(url, payload, headers)
  return M.sendJsonO('POST', url, payload, headers)
end

function M.patchJsonO(url, payload, headers)
  return M.sendJsonO('PATCH', url, payload, headers)
end

--------------------------------------------------------------------------------
--                    code copied from the lhttp
--------------------------------------------------------------------------------

function M.get_scheme(url, def)
  return url ~= nil and (string.match(url, '^(%w+)://') or def) or nil
end

function M.is_full_url(s)
  if s ~= nil then
    local scheme = M.get_scheme(s, false)
    return scheme ~= nil and scheme ~= ''
  end
  return false
end

--
-- host="http://localhost"  uri="webapp/post/{id}/edit"  params={ id = 1 }
-- will give  -->  'http://localhost/webapp/post/1/edit'
--
---@param host string
---@param uri string
---@param params table?
---@return string
function M.build_url(host, uri, params)
  host = host or ''
  uri = uri or ''
  local sep

  local isfull = M.is_full_url(uri)
  if isfull then
    host, sep = '', ''
  else
    local uri_starts_slash = uri:sub(1, 1) == '/'
    local host_addr_ends_slash = host:sub(-1, -1) == '/'
    sep = (not uri_starts_slash and not host_addr_ends_slash) and '/' or ''

    if uri_starts_slash and host_addr_ends_slash then
      uri = uri:sub(2)
    end
  end
  log_debug('build_url host:%s uri:%s (isfull:%s) params:%s',
    host, uri, isfull, params)

  local ptype = type(params)
  if ptype == 'string' then
    error('expected table params')
  elseif ptype == 'table' then
    local val2s = socket_url.escape

    for k, v in pairs(params) do
      local tmpl = '{' .. k .. '}'
      local i, j = string.find(uri, tmpl)
      if i and j then
        uri = uri:sub(1, i - 1) .. val2s(v) .. uri:sub(j + 1)
      end
    end
  end

  local unresolved = string.match(uri, '({[^%{%}]*})')
  if unresolved then
    error('has unresolved query parameter ' .. unresolved)
  end

  return host .. sep .. uri
end

return M
